import { Component, OnInit } from '@angular/core';
import { Invoice } from '../../models/invoice';
import { invoiceService } from '../../servicers/invoices.service';

@Component({
  selector: 'app-invoice',
  standalone: true,
  imports: [],
  templateUrl: './invoice.component.html'
})
export class InvoiceComponent implements OnInit {
  invoice!: Invoice;

  constructor(private service: invoiceService ) { }

  ngOnInit(): void {
    this.invoice = this.service.getInvoices();
  }

}
