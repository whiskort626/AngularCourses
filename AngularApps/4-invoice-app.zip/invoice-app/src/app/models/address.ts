export class Address {
    country: string;
    city: string;
    street: string;
    number: number;

    constructor(country: string, city: string, street: string, number: number) {
        this.country = country;
        this.city = city;
        this.street = street;
        this.number = number;
    }
}