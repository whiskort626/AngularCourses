import { Injectable } from '@angular/core';
import { Invoice } from '../models/invoice';
import { InvoiceData } from '../data/invoice.data';

@Injectable({
  providedIn: 'root'
})
export class invoiceService {
  private invoices: Invoice[] = InvoiceData;
  constructor() { }
  getInvoices(): Invoice {
    const total = this.calculateTotal();
    return { ...this.invoices[0], total };
  }

  calculateTotal(): number {
    return this.invoices[0].items.reduce((total, item) => total + (item.price * item.quantity), 0);
  }
}
